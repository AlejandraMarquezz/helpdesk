from flask import Blueprint, render_template, request, redirect, session
from db import get_connection
from datetime import datetime

tickets_bp = Blueprint("tickets", __name__)

@tickets_bp.route("/")
def index():
    if "usuario" not in session:
        return redirect("/login")
    conn = get_connection()
    cur = conn.cursor()

    # Si es técnico, ve todos; si no, solo los suyos
    if session["rol"] == "tecnico":
        cur.execute("SELECT * FROM tickets ORDER BY id DESC")
    else:
        cur.execute("SELECT * FROM tickets WHERE reportado_por=? ORDER BY id DESC", (session["usuario"],))
    tickets = cur.fetchall()
    conn.close()
    return render_template("index.html", tickets=tickets, usuario=session["usuario"], rol=session["rol"])

@tickets_bp.route("/nuevo", methods=["POST"])
def nuevo():
    if "usuario" not in session:
        return redirect("/login")
    titulo = request.form["titulo"]
    descripcion = request.form["descripcion"]
    prioridad = request.form["prioridad"]
    reportado_por = session["usuario"]
    conn = get_connection()
    conn.execute(
        "INSERT INTO tickets (titulo, descripcion, reportado_por, prioridad) VALUES (?, ?, ?, ?)",
        (titulo, descripcion, reportado_por, prioridad),
    )
    conn.commit()
    conn.close()
    return redirect("/")

@tickets_bp.route("/iniciar/<int:id>", methods=["POST"])
def iniciar(id):
    """Marca un ticket como en proceso y asigna la fecha de inicio."""
    if "usuario" not in session or session["rol"] != "tecnico":
        return redirect("/")
    conn = get_connection()
    fecha_inicio = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("UPDATE tickets SET estado=?, fecha_inicio=? WHERE id=?", ("en proceso", fecha_inicio, id))
    conn.commit()
    conn.close()
    return redirect("/")

@tickets_bp.route("/cerrar/<int:id>", methods=["POST"])
def cerrar(id):
    """Cierra un ticket, agrega fecha de finalización y descripción técnica."""
    if "usuario" not in session or session["rol"] != "tecnico":
        return redirect("/")
    descripcion_tecnico = request.form.get("descripcion_tecnico", "").strip()
    fecha_final = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_connection()
    conn.execute(
        "UPDATE tickets SET estado=?, fecha_finalizacion=?, descripcion_tecnico=? WHERE id=?",
        ("cerrado", fecha_final, descripcion_tecnico, id),
    )
    conn.commit()
    conn.close()
    return redirect("/")